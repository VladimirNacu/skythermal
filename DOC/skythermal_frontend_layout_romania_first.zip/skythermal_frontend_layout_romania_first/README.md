# SkyThermal Romania-First Front-End Layout

React/Vite starter layout for a Romania-first paragliding meteo dashboard.

## Run

```bash
npm install
npm run dev
```

## Romania-first changes

- Default country: Romania
- Default selected site: Bunloc, Brașov
- Favorite sites: Bunloc, Postăvaru / Poiana Brașov, Lempes Hill, Sinaia / Bucegi, Clopotiva / Retezat, Rimetea / Apuseni
- Map concept: Carpathians / Transylvania
- Weather strategy: Open-Meteo for demo, then GFS/ECMWF GRIB for production particles
- Airspace strategy: official ROMATSA/AIS validation before safety recommendations

## Important safety note

All site data in this demo must be validated with local Romanian pilots/clubs before being used for real GO / NO-GO recommendations.
