import React from "react";
import { createRoot } from "react-dom/client";
import {
  Search, Star, Plus, Wind, CloudSun, CloudRain, Zap, Eye, Thermometer,
  Mountain, Gauge, Car, Navigation, Layers, Crosshair, Maximize, Ruler,
  Play, ChevronDown, MapPin, Plane, BrainCircuit, Clock, ShieldAlert,
  Cloud, Activity
} from "lucide-react";
import "./styles.css";

const favoriteSites = [
  { name: "Bunloc", country: "Romania", active: true },
  { name: "Postăvaru / Poiana Brașov", country: "Romania" },
  { name: "Lempes Hill", country: "Romania" },
  { name: "Sinaia / Bucegi", country: "Romania" },
  { name: "Clopotiva / Retezat", country: "Romania" },
  { name: "Rimetea / Apuseni", country: "Romania" }
];

const layers = [
  { id: "surfaceWind", label: "Surface Wind", icon: Wind, active: true },
  { id: "altitudeWind", label: "Wind at Altitude", value: "1000 m", icon: Wind, active: true },
  { id: "gusts", label: "Gusts", icon: Activity },
  { id: "thermals", label: "Thermals", icon: Gauge },
  { id: "cloudbase", label: "Cloudbase", icon: Cloud },
  { id: "cape", label: "CAPE / Instability", icon: ShieldAlert },
  { id: "rainRadar", label: "Rain Radar", icon: CloudRain },
  { id: "lightning", label: "Lightning", icon: Zap },
  { id: "visibility", label: "Visibility", icon: Eye },
  { id: "tempDewpoint", label: "Temperature / Dewpoint", icon: Thermometer },
  { id: "rotor", label: "Wave / Rotor Risk", icon: Mountain },
  { id: "foehn", label: "Foehn Indicator", icon: Wind }
];

const hourly = [
  { t: "08:00", wind: 5, gust: 11, thermals: 1.1, cloudbase: 1100, rain: "0%" },
  { t: "09:00", wind: 7, gust: 14, thermals: 1.6, cloudbase: 1350, rain: "0%" },
  { t: "10:00", wind: 9, gust: 18, thermals: 2.1, cloudbase: 1600, rain: "0%" },
  { t: "11:00", wind: 11, gust: 22, thermals: 2.8, cloudbase: 1850, rain: "0%" },
  { t: "12:00", wind: 13, gust: 25, thermals: 3.1, cloudbase: 2050, rain: "0%" },
  { t: "13:00", wind: 15, gust: 27, thermals: 3.0, cloudbase: 2150, rain: "0%" },
  { t: "14:00", wind: 14, gust: 24, thermals: 2.5, cloudbase: 2000, rain: "0%" },
  { t: "15:00", wind: 12, gust: 20, thermals: 2.0, cloudbase: 1800, rain: "0%" },
  { t: "16:00", wind: 10, gust: 18, thermals: 1.4, cloudbase: 1500, rain: "5%" },
  { t: "17:00", wind: 8, gust: 15, thermals: 1.0, cloudbase: 1250, rain: "5%" }
];

const markers = [
  { left: "46%", top: "42%", type: "blue", label: "Bunloc" },
  { left: "42%", top: "34%", type: "green", label: "Postăvaru" },
  { left: "51%", top: "48%", type: "green", label: "Lempes" },
  { left: "36%", top: "30%", type: "green" },
  { left: "31%", top: "62%", type: "green" },
  { left: "58%", top: "29%", type: "orange" },
  { left: "66%", top: "55%", type: "green" },
  { left: "27%", top: "48%", type: "orange" }
];

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand"><div className="brandMark" /><span>SkyThermal RO</span></div>
      <div className="searchBox"><Search size={16}/><input placeholder="Search Romanian launch or region..." /><kbd>⌘ K</kbd></div>

      <div className="sideHeader"><span>Romania favorite sites</span><button className="iconButton small"><Plus size={15}/></button></div>
      <div className="favorites">
        {favoriteSites.map(site => (
          <button className={`favoriteItem ${site.active ? "active" : ""}`} key={site.name}>
            <MapPin size={14}/><span><b>{site.name}</b><small>{site.country}</small></span>
            <Star size={14} className={site.active ? "starOn" : ""}/>
          </button>
        ))}
      </div>

      <div className="sideHeader layersHeader"><span>Quick layers</span></div>
      <div className="layerList">
        {layers.map(layer => {
          const Icon = layer.icon;
          return (
            <button className={`layerRow ${layer.active ? "active" : ""}`} key={layer.id}>
              <Icon size={15}/><span>{layer.label}</span>{layer.value && <em>{layer.value}</em>}<i className={`toggle ${layer.active ? "on" : ""}`}/>
            </button>
          );
        })}
      </div>

      <div className="driveCard">
        <div className="cardTitle"><span>Drive or Don't Drive</span><button>?</button></div>
        <div className="driveGauge">
          <div className="gaugeArc"/><Car size={38}/><strong>GO</strong>
          <p>Good Brașov window.<br/>Worth the drive.</p><a>Show details →</a>
        </div>
      </div>
    </aside>
  );
}

function MapCanvas() {
  return (
    <main className="mapShell">
      <div className="mapBackground">
        <div className="topLegend"><span>Wind speed (km/h)</span><div className="legendGradient">{[0,10,20,30,40,50,60,70,"80+"].map(v => <b key={v}>{v}</b>)}</div></div>
        <div className="altitudeControl"><span>Altitude</span>{["Surface","500 m","1000 m","1500 m","2000 m"].map(a => <button className={a==="1000 m" ? "selected" : ""} key={a}>{a}</button>)}</div>
        <div className="airspaceChip">Airspace <strong>ON</strong><ChevronDown size={13}/></div>
        <div className="airspaceZone zoneOne">LRBB FIR<br/>check NOTAM</div>
        <div className="airspaceZone zoneTwo">CTR BRAȘOV<br/>validate limits</div>

        <div className="mapLabels">
          <span style={{left:"9%",top:"14%"}}>Cluj-Napoca</span><span style={{left:"23%",top:"20%"}}>Sibiu</span>
          <span style={{left:"31%",top:"38%"}}>Făgăraș</span><span style={{left:"43%",top:"47%"}}>Brașov</span>
          <span style={{left:"54%",top:"38%"}}>Bucegi</span><span style={{left:"63%",top:"54%"}}>Ploiești</span>
          <span style={{left:"70%",top:"73%"}}>Bucharest</span><span style={{left:"80%",top:"24%"}}>Iași</span>
          <span style={{left:"16%",top:"68%"}}>Retezat</span><span style={{left:"50%",top:"22%"}}>Transylvania</span>
        </div>

        {markers.map((m, i) => <div className={`siteMarker ${m.type}`} style={{left:m.left, top:m.top}} key={i}><Plane size={15}/>{m.label && <span>{m.label}</span>}</div>)}

        <div className="mapControls"><button><Navigation size={18}/></button><button>+</button><button>−</button><button><Layers size={18}/></button><button><Crosshair size={18}/></button><button>3D</button><button><Ruler size={17}/></button><button><Maximize size={17}/></button></div>
      </div>
      <Timeline/>
    </main>
  );
}

function Timeline() {
  const times = ["02:00","05:00","08:00","11:00","14:00","17:00","20:00","23:00"];
  return <section className="timelinePanel">
    <div className="timelineTop"><button className="dateButton">Today <small>Romania local time</small><ChevronDown size={14}/></button><button className="playButton"><Play size={17} fill="currentColor"/></button><div className="timeTrack">{times.map(t => <span key={t}>{t}</span>)}<div className="currentTime"><b>11:00</b></div></div><div className="rangeButtons"><button className="active">1D</button><button>3D</button><button>5D</button><button><Layers size={16}/></button></div></div>
    <div className="timelineRows"><WeatherStrip label="Wind (km/h)" values={[5,7,9,11,13,15,14,12,10,8]}/><WeatherStrip label="Gusts (km/h)" values={[11,14,18,22,25,27,24,20,18,15]}/><WeatherStrip label="Thermals (m/s)" values={[0.4,0.8,1.6,2.8,3.1,3.0,2.5,2.0,1.4,1.0]}/><WeatherStrip label="Cloud base (m)" values={[800,1100,1350,1850,2050,2150,2000,1800,1500,1250]}/></div>
  </section>;
}

function WeatherStrip({label, values}) { return <div className="weatherStrip"><span>{label}</span><div className="stripGradient">{values.map((v,i)=><b key={i}>{v}</b>)}</div></div>; }

function RightPanel() {
  return <aside className="rightPanel">
    <div className="siteTitle"><div><h1><Star size={18} fill="currentColor"/> Bunloc</h1><small>Brașov, Romania</small></div><button>×</button></div>
    <nav className="tabs"><button className="active">Overview</button><button>Forecast</button><button>Details</button><button>Notes</button></nav>
    <div className="metricGrid">
      <Metric title="Flyability Score" value="79" suffix="/100" note="Good day" ring="green"/>
      <Metric title="Risk Score" value="31" suffix="/100" note="Moderate-low" ring="yellow"/>
      <Metric title="Wind at Launch" value="11" suffix="km/h" note="NW" icon={<Wind size={22}/>}/>
      <Metric title="Gusts" value="22" suffix="km/h" icon={<Activity size={22}/>}/>
      <Metric title="Cloudbase" value="1850" suffix="m" note="AGL" icon={<CloudSun size={23}/>}/>
      <Metric title="Thermals" value="Good" suffix="2.8 m/s" icon={<Gauge size={23}/>}/>
    </div>
    <div className="launchWindow"><span>Best launch window</span><strong>11:00 – 15:00</strong><small>RO local</small></div>
    <button className="goBar"><Clock size={20}/><b>GO</b> Good conditions <ChevronDown size={16}/></button>
    <MiniForecast/>
    <div className="aiCard"><h3><BrainCircuit size={20}/> AI Flight Briefing <em>BETA</em></h3><p>High pressure over central Romania and strong Carpathian heating should generate useful thermals by late morning. Watch for valley-wind increase in the afternoon and validate launch wind locally before takeoff.</p><div className="confidence"><span>Confidence: <b>Medium-high</b></span><div><i/></div><strong>86%</strong></div></div>
  </aside>;
}

function Metric({title, value, suffix, note, ring, icon}) {
  return <div className="metricCard"><span>{title}</span><div className="metricBody">{icon && <div className="metricIcon">{icon}</div>}<strong>{value}<small>{suffix}</small></strong>{ring && <div className={`ring ${ring}`}/>}</div>{note && <p>{note}</p>}</div>;
}

function MiniForecast() {
  return <div className="miniForecast"><h3>Today, Romania</h3><div className="forecastTable"><div className="forecastRow head"><span/>{hourly.map(h=><b key={h.t}>{h.t}</b>)}</div><div className="forecastRow icons"><span/>{hourly.map((h,i)=><b key={h.t}>{i<3?"☀️":"🌤️"}</b>)}</div><ForecastRow label="km/h" field="wind"/><ForecastRow label="gusts" field="gust" highlight/><ForecastRow label="thermals" field="thermals" highlight/><ForecastRow label="cloud base" field="cloudbase"/><ForecastRow label="rain" field="rain"/></div></div>;
}
function ForecastRow({label, field, highlight}) { return <div className="forecastRow"><span>{label}</span>{hourly.map((h,i)=><b className={highlight && i>=3 && i<=7 ? "good" : ""} key={h.t}>{h[field]}</b>)}</div>; }

function App(){ return <div className="app"><Sidebar/><MapCanvas/><RightPanel/></div>; }
createRoot(document.getElementById("root")).render(<App/>);
